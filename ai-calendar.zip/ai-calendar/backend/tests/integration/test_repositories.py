from datetime import datetime, timedelta, timezone

import pytest

from app.persistence.db import Base, create_session_factory, create_sqlite_engine
from app.persistence.repositories import CalendarRepository, DraftRepository, ModelRunRepository, PlanningSessionRepository


@pytest.fixture
def db():
    engine = create_sqlite_engine("sqlite+pysqlite:///:memory:")
    Base.metadata.create_all(engine)
    with create_session_factory(engine)() as session:
        yield session


def test_planning_session_can_be_created_and_read_back(db) -> None:
    now = datetime(2026, 8, 30, 10, tzinfo=timezone.utc)
    repo = PlanningSessionRepository(db)

    created = repo.create(raw_input="周三下午3点开会", reference_now=now)
    loaded = repo.get(created.id)

    assert loaded is not None
    assert loaded.status == "received"
    assert loaded.raw_input == "周三下午3点开会"


def test_draft_and_items_are_saved_together(db) -> None:
    now = datetime(2026, 8, 30, 10, tzinfo=timezone.utc)
    planning = PlanningSessionRepository(db).create(raw_input="我要散步", reference_now=now)
    repo = DraftRepository(db)

    draft = repo.create_with_items(
        session_id=planning.id,
        window_start=now,
        window_end=now + timedelta(days=14),
        items=[{"kind": "scheduled", "title": "散步30分钟", "start_at": now + timedelta(days=1), "end_at": now + timedelta(days=1, minutes=30)}],
    )

    items = repo.get_items(draft.id)
    assert draft.status == "ready"
    assert len(items) == 1
    assert items[0].title == "散步30分钟"


def test_overlap_query_excludes_events_touching_window_boundary(db) -> None:
    repo = CalendarRepository(db)
    start = datetime(2026, 9, 1, 10, tzinfo=timezone.utc)
    end = start + timedelta(hours=1)
    repo.add(source="ai", title="重叠会议", start_at=start + timedelta(minutes=30), end_at=end + timedelta(minutes=30))
    repo.add(source="ai", title="刚好结束", start_at=start - timedelta(hours=1), end_at=start)
    repo.add(source="ai", title="刚好开始", start_at=end, end_at=end + timedelta(hours=1))

    events = repo.overlapping(start=start, end=end)

    assert [event.title for event in events] == ["重叠会议"]


def test_aware_datetime_round_trips_through_sqlite_as_utc() -> None:
    engine = create_sqlite_engine("sqlite+pysqlite:///:memory:")
    Base.metadata.create_all(engine)
    factory = create_session_factory(engine)
    original = datetime(2026, 8, 30, 10, tzinfo=timezone(timedelta(hours=8)))
    with factory() as first:
        row = PlanningSessionRepository(first).create(raw_input="开会", reference_now=original)
        row_id = row.id
    with factory() as second:
        loaded = PlanningSessionRepository(second).get(row_id)
        assert loaded.reference_now.tzinfo is not None
        assert loaded.reference_now == original


def test_model_run_audit_and_atomic_status_claim_are_persisted(db) -> None:
    planning = PlanningSessionRepository(db)
    session = planning.create(raw_input="安排开会", reference_now=datetime.now(timezone.utc))

    assert planning.claim_status(session.id, expected="received", claimed="a_processing") is True
    assert planning.claim_status(session.id, expected="received", claimed="a_processing") is False

    run = ModelRunRepository(db).record(
        session_id=session.id,
        stage="a",
        prompt_version="phase-a-v3",
        model="test-model",
        request_id="request-1",
        validated_json={"decision": "ready"},
        latency_ms=12,
        status="succeeded",
        error_type=None,
    )

    assert run.session_id == session.id
    assert ModelRunRepository(db).list_for_session(session.id)[0].validated_json == {"decision": "ready"}
