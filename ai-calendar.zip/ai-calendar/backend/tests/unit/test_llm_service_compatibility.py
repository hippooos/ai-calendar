import pytest

from app.llm.service import ModelOutputValidationError, PlanningLLMService
from tests.contract.test_prompt_schemas import phase_a_payload
from tests.e2e.test_phase_one_flow import GoalLLMService


class FalseManualRequiredClient:
    async def complete_json(self, *, system_prompt, payload):
        result = phase_a_payload()
        result["manual_required"] = False
        return result


@pytest.mark.asyncio
async def test_phase_a_treats_false_manual_required_as_no_manual_intervention() -> None:
    result = await PlanningLLMService(FalseManualRequiredClient()).run_phase_a({})

    assert result.manual_required is None


class InvalidPhaseAOutputClient:
    async def complete_json(self, *, system_prompt, payload):
        return {"decision": "ready", "items": "not-an-array"}


@pytest.mark.asyncio
async def test_phase_a_validation_error_keeps_raw_model_output_and_field_errors() -> None:
    with pytest.raises(ModelOutputValidationError) as raised:
        await PlanningLLMService(InvalidPhaseAOutputClient()).run_phase_a({})

    error = raised.value
    assert error.raw_output == {"decision": "ready", "items": "not-an-array"}
    assert any(item["loc"] == ("items",) for item in error.validation_errors)


class MissingStartQuestionClient:
    async def complete_json(self, *, system_prompt, payload):
        result = phase_a_payload()
        item = result["items"][0]
        item["facts"]["start_time"] = None
        item["hard_constraints"]["fixed_start_time"] = None
        item["hard_constraints"]["required_periods"] = ["afternoon"]
        item["critical_missing"] = []
        result.update({"decision": "ready", "questions": [], "manual_required": None})
        return result


@pytest.mark.asyncio
async def test_phase_a_repairs_missing_start_time_into_one_clarification() -> None:
    result = await PlanningLLMService(MissingStartQuestionClient()).run_phase_a({})

    assert result.decision.value == "needs_clarification"
    assert result.questions[0].missing_field == "facts.start_time"
    assert result.questions[0].covers_item_ids == [result.items[0].item_id]


class ExistingStartQuestionClient(MissingStartQuestionClient):
    async def complete_json(self, *, system_prompt, payload):
        result = await super().complete_json(system_prompt=system_prompt, payload=payload)
        result["questions"] = [{
            "question_id": "q_existing",
            "priority": 30,
            "missing_field": "facts.start_time",
            "question": "这场会议几点开始？",
            "covers_item_ids": [result["items"][0]["item_id"]],
            "input_type": "single_choice",
            "options": [{"label": "15:00", "value": "15:00"}],
            "allow_custom_input": True,
        }]
        return result


@pytest.mark.asyncio
async def test_phase_a_does_not_duplicate_an_existing_start_time_question() -> None:
    result = await PlanningLLMService(ExistingStartQuestionClient()).run_phase_a({})

    assert len(result.questions) == 1
    assert result.questions[0].question_id == "q_existing"


class ObjectAssumptionClient:
    async def complete_json(self, *, system_prompt, payload):
        result = phase_a_payload()
        result["items"][0]["assumptions"] = [{
            "field_path": "facts.end_time",
            "value": None,
            "reason": "未提供结束时间",
        }]
        return result


@pytest.mark.asyncio
async def test_phase_a_normalizes_assumption_objects_to_visible_reason_text() -> None:
    result = await PlanningLLMService(ObjectAssumptionClient()).run_phase_a({})

    assert result.items[0].assumptions == ["未提供结束时间"]


class BeforeEventDeadlineClient:
    async def complete_json(self, *, system_prompt, payload):
        result = phase_a_payload()
        result["items"].append({
            "item_id": "item_2",
            "kind": "abstract_goal",
            "source_text": "我想在之前每天准备一下",
            "title": "会议准备",
            "facts": {"date": None, "start_time": None, "end_time": None, "duration_minutes": None,
                      "deadline": "2026-09-02", "stated_frequency": "每天", "activity": "准备会议", "result_metric": None},
            "hard_constraints": {"allowed_weekdays": [], "required_periods": [], "fixed_date": None,
                                 "fixed_start_time": None, "must_finish_before": "2026-09-02T00:00:00"},
            "soft_preferences": {"preferred_periods": []},
            "provenance": [], "critical_missing": [], "assumptions": [],
        })
        return result


@pytest.mark.asyncio
async def test_phase_a_normalizes_before_event_deadline_to_the_event_start_time() -> None:
    result = await PlanningLLMService(BeforeEventDeadlineClient()).run_phase_a({"timezone": "Asia/Shanghai"})

    assert result.items[1].hard_constraints.must_finish_before.isoformat() == "2026-09-02T15:00:00+08:00"


class PeriodWrittenAsStartTimeClient:
    async def complete_json(self, *, system_prompt, payload):
        result = phase_a_payload()
        item = result["items"][0]
        item["facts"]["start_time"] = "morning"
        item["hard_constraints"]["fixed_start_time"] = "morning"
        return result


@pytest.mark.asyncio
async def test_phase_a_keeps_a_period_token_in_start_time_as_a_clarification_signal() -> None:
    result = await PlanningLLMService(PeriodWrittenAsStartTimeClient()).run_phase_a({})

    assert result.decision.value == "needs_clarification"
    assert result.items[0].facts.start_time is None
    assert result.items[0].hard_constraints.required_periods == ["morning"]
    assert any(question.missing_field == "facts.start_time" for question in result.questions)


class AliasPhaseBClient:
    def __init__(self, raw):
        self.raw = raw

    async def complete_json(self, *, system_prompt, payload):
        return self.raw


@pytest.mark.asyncio
async def test_phase_b_normalizes_known_goal_aliases_and_source_object() -> None:
    fixture = GoalLLMService()
    phase_a = await fixture.run_phase_a({})
    raw = (await fixture.run_phase_b(phase_a, {})).model_dump(mode="json")
    plan = raw["goal_plans"][0]
    plan["goal_id"] = plan.pop("source_item_id")
    plan["title"] = plan.pop("goal_title")
    plan["task_templates"][0]["source"] = {"item_id": "goal_1", "source_text": "用户原文"}

    result = await PlanningLLMService(AliasPhaseBClient(raw)).run_phase_b(phase_a, {})

    assert result.goal_plans[0].source_item_id == "goal_1"
    assert result.goal_plans[0].goal_title == "规律散步"
    assert result.goal_plans[0].task_templates[0].source.value == "user_input"


@pytest.mark.asyncio
async def test_phase_b_normalizes_ai_provenance_display_labels() -> None:
    fixture = GoalLLMService()
    phase_a = await fixture.run_phase_a({})
    raw = (await fixture.run_phase_b(phase_a, {})).model_dump(mode="json")
    raw["goal_plans"][0]["task_templates"][0]["provenance"] = [
        {
            "field_path": "instructions",
            "value": "每天准备 60 分钟",
            "source": "ai_suggestion",
            "reason": "给出日常建议",
            "user_editable": True,
            "display_label": "AI建议，可修改",
        },
        {
            "field_path": "duration_minutes",
            "value": 60,
            "source": "ai_assumption",
            "reason": "用户未提供时长",
            "user_editable": True,
            "display_label": "默认 60 分钟",
        },
    ]

    result = await PlanningLLMService(AliasPhaseBClient(raw)).run_phase_b(phase_a, {})

    labels = [entry.display_label for entry in result.goal_plans[0].task_templates[0].provenance]
    assert labels == ["AI建议，可修改或删除", "AI猜测，可修改"]


@pytest.mark.asyncio
async def test_phase_b_accepts_a_single_deadline_provenance_wrapped_in_a_list() -> None:
    fixture = GoalLLMService()
    phase_a = await fixture.run_phase_a({})
    raw = (await fixture.run_phase_b(phase_a, {})).model_dump(mode="json")
    raw["goal_plans"][0]["deadline_provenance"] = [{
        "field_path": "deadline",
        "value": "2026-10-01",
        "source": "ai_assumption",
        "reason": "用户未给期限，使用默认期限",
        "user_editable": True,
        "display_label": "AI猜测，可修改",
    }]

    result = await PlanningLLMService(AliasPhaseBClient(raw)).run_phase_b(phase_a, {})

    assert result.goal_plans[0].deadline_provenance is not None
    assert result.goal_plans[0].deadline_provenance.field_path == "deadline"


@pytest.mark.asyncio
async def test_phase_b_removes_an_ai_invented_hard_gap_from_a_study_task() -> None:
    fixture = GoalLLMService()
    phase_a = await fixture.run_phase_a({})
    raw = (await fixture.run_phase_b(phase_a, {})).model_dump(mode="json")
    task = raw["goal_plans"][0]["task_templates"][0]
    task.update({"activity_type": "study", "min_gap_hours": 36})
    task["provenance"] = [{
        "field_path": "task_template.min_gap_hours", "value": 36,
        "source": "ai_suggestion", "reason": "模型建议", "user_editable": True,
        "display_label": "AI建议，可修改或删除",
    }]

    result = await PlanningLLMService(AliasPhaseBClient(raw)).run_phase_b(phase_a, {})

    assert result.goal_plans[0].task_templates[0].min_gap_hours == 0


class DateTimeDeadlineClient:
    async def complete_json(self, *, system_prompt, payload):
        result = phase_a_payload()
        result["items"][0]["kind"] = "abstract_goal"
        result["items"][0]["facts"]["deadline"] = "2026-09-05T14:00:00+08:00"
        result["items"][0]["hard_constraints"]["must_finish_before"] = "2026-09-05T14:00:00+08:00"
        return result


@pytest.mark.asyncio
async def test_phase_a_converts_a_datetime_deadline_to_a_calendar_date() -> None:
    result = await PlanningLLMService(DateTimeDeadlineClient()).run_phase_a({})

    assert result.items[0].facts.deadline.isoformat() == "2026-09-05"
    assert result.items[0].hard_constraints.must_finish_before.isoformat() == "2026-09-05T14:00:00+08:00"


@pytest.mark.asyncio
async def test_phase_b_normalizes_datetime_deadline_null_gap_and_fragmented_pacing() -> None:
    fixture = GoalLLMService()
    phase_a = await fixture.run_phase_a({})
    raw = (await fixture.run_phase_b(phase_a, {})).model_dump(mode="json")
    plan = raw["goal_plans"][0]
    task = plan["task_templates"][0]
    plan["deadline"] = "2026-10-01T14:00:00+08:00"
    task.update({"activity_type": "study", "min_gap_hours": None})
    task["soft_preferences"]["pacing"] = "fragmented"

    result = await PlanningLLMService(AliasPhaseBClient(raw)).run_phase_b(phase_a, {})

    normalized = result.goal_plans[0]
    assert normalized.deadline.isoformat() == "2026-10-01"
    assert normalized.task_templates[0].min_gap_hours == 0
    assert normalized.task_templates[0].soft_preferences.pacing == "fragmented"
