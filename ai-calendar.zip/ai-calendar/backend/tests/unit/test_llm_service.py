from typing import Any

import pytest

from app.llm.service import ModelOutputValidationError, PlanningLLMService
from app.prompts.schemas import PhaseAResult
from tests.contract.test_prompt_schemas import phase_a_payload, phase_b_payload


class FakeJSONClient:
    def __init__(self, *responses: dict[str, Any]) -> None:
        self.responses = list(responses)

    async def complete_json(self, *, system_prompt: str, payload: dict[str, Any]) -> dict[str, Any]:
        return self.responses.pop(0)


def compound_trip_payload(*, merged: bool) -> dict[str, Any]:
    def event(item_id: str, title: str, day: str, start: str) -> dict[str, Any]:
        return {
            "item_id": item_id, "kind": "explicit_event", "source_text": title, "title": title,
            "facts": {"date": day, "start_time": start, "end_time": None, "duration_minutes": 60,
                      "deadline": None, "stated_frequency": None, "activity": title, "result_metric": None},
            "hard_constraints": {"allowed_weekdays": [], "required_periods": [],
                                 "fixed_date": day, "fixed_start_time": start},
            "soft_preferences": {"preferred_periods": []},
            "provenance": [], "critical_missing": [], "assumptions": [],
        }

    if merged:
        items = [event("merged", "请假前往zz处理流程、开学注册及宣讲会", "2026-09-23", "10:00")]
    else:
        items = [
            event("leave", "请假", "2026-09-22", "09:00"),
            event("process", "前往zz处理流程", "2026-09-23", "14:00"),
            event("registration", "开学注册", "2026-09-23", "10:00"),
            event("briefing", "参加宣讲会", "2026-09-23", "19:00"),
        ]
    return {"decision": "ready", "items": items, "questions": [], "manual_required": None,
            "global_assumptions": []}


@pytest.mark.asyncio
async def test_phase_a_rejects_model_output_outside_contract() -> None:
    service = PlanningLLMService(FakeJSONClient({"decision": "ready"}))

    with pytest.raises(ModelOutputValidationError):
        await service.run_phase_a({"user_input": "周三开会"})


@pytest.mark.asyncio
async def test_phase_a_returns_validated_result() -> None:
    service = PlanningLLMService(FakeJSONClient(phase_a_payload()))

    result = await service.run_phase_a({"user_input": "9月2日15点到16点开会"})

    assert isinstance(result, PhaseAResult)
    assert result.items[0].title == "开会"


@pytest.mark.asyncio
async def test_phase_a_retries_once_when_a_compound_trip_is_merged() -> None:
    service = PlanningLLMService(FakeJSONClient(
        compound_trip_payload(merged=True),
        compound_trip_payload(merged=False),
    ))

    result = await service.run_phase_a({
        "reference_now": "2026-09-18T10:00:00+08:00",
        "user_input": "周三前我想请假前往zz处理流程、开学注册及宣讲会",
    })

    assert [item.item_id for item in result.items] == ["leave", "process", "registration", "briefing"]


@pytest.mark.asyncio
async def test_phase_a_rejects_a_compound_trip_that_is_still_merged_after_retry() -> None:
    service = PlanningLLMService(FakeJSONClient(
        compound_trip_payload(merged=True),
        compound_trip_payload(merged=True),
    ))

    with pytest.raises(ModelOutputValidationError) as captured:
        await service.run_phase_a({
            "reference_now": "2026-09-18T10:00:00+08:00",
            "user_input": "周三前我想请假前往zz处理流程、开学注册及宣讲会",
        })

    assert captured.value.validation_errors[0]["type"] == "value_error.semantic_coverage"


@pytest.mark.asyncio
async def test_phase_b_rejects_changed_fixed_event() -> None:
    phase_a = PhaseAResult.model_validate(phase_a_payload())
    changed = phase_b_payload()
    changed["fixed_events"][0]["start_time"] = "15:30"
    service = PlanningLLMService(FakeJSONClient(changed, changed))

    with pytest.raises(ModelOutputValidationError) as captured:
        await service.run_phase_b(phase_a, {"timezone": "Asia/Shanghai"})

    assert captured.value.raw_output == changed
    assert captured.value.validation_errors == [{
        "loc": ["phase_transition"],
        "msg": "固定事件的标题或时间事实被阶段 B 修改",
        "type": "value_error.phase_transition",
    }]


def compound_trip_phase_b_payload(*, omit_briefing: bool) -> dict[str, Any]:
    phase_a = compound_trip_payload(merged=False)
    events = []
    for item in phase_a["items"]:
        if omit_briefing and item["item_id"] == "briefing":
            continue
        events.append({
            "source_item_id": item["item_id"], "title": item["title"],
            "date": item["facts"]["date"], "start_time": item["facts"]["start_time"],
            "end_time": item["facts"]["end_time"], "duration_minutes": item["facts"]["duration_minutes"],
            "assumptions": [],
        })
    return {"decision": "ready_for_scheduling", "fixed_events": events, "goal_plans": [], "assumptions": []}


@pytest.mark.asyncio
async def test_phase_b_retries_once_when_it_omits_a_fixed_event() -> None:
    phase_a = PhaseAResult.model_validate(compound_trip_payload(merged=False))
    service = PlanningLLMService(FakeJSONClient(
        compound_trip_phase_b_payload(omit_briefing=True),
        compound_trip_phase_b_payload(omit_briefing=False),
    ))

    result = await service.run_phase_b(phase_a, {"timezone": "Asia/Shanghai"})

    assert [event.source_item_id for event in result.fixed_events] == [
        "leave", "process", "registration", "briefing",
    ]


@pytest.mark.asyncio
async def test_phase_b_rejects_a_fixed_event_omission_that_survives_retry() -> None:
    phase_a = PhaseAResult.model_validate(compound_trip_payload(merged=False))
    service = PlanningLLMService(FakeJSONClient(
        compound_trip_phase_b_payload(omit_briefing=True),
        compound_trip_phase_b_payload(omit_briefing=True),
    ))

    with pytest.raises(ModelOutputValidationError, match="模型输出未通过结构校验"):
        await service.run_phase_b(phase_a, {"timezone": "Asia/Shanghai"})


@pytest.mark.asyncio
async def test_phase_a_asks_for_exact_time_when_the_model_writes_a_period_for_an_explicit_event() -> None:
    payload = phase_a_payload()
    payload["items"][0]["facts"]["start_time"] = "下午"
    payload["items"][0]["hard_constraints"]["fixed_start_time"] = "下午"
    service = PlanningLLMService(FakeJSONClient(payload))

    result = await service.run_phase_a({"user_input": "周三下午和客户开会"})

    item = result.items[0]
    assert result.decision.value == "needs_clarification"
    assert item.facts.start_time is None
    assert item.hard_constraints.fixed_start_time is None
    assert item.hard_constraints.required_periods == ["afternoon"]
    assert "facts.start_time" in item.critical_missing
    assert any(question.missing_field == "facts.start_time" for question in result.questions)


@pytest.mark.asyncio
async def test_phase_a_converts_goal_periods_into_default_times() -> None:
    payload = phase_a_payload()
    payload["items"][0] = {
        "item_id": "goal_1",
        "kind": "abstract_goal",
        "source_text": "每周下午快走",
        "title": "快走",
        "facts": {"date": None, "start_time": "下午", "end_time": None, "duration_minutes": 30,
                  "deadline": None, "stated_frequency": "每周三次", "activity": "快走", "result_metric": None},
        "hard_constraints": {"allowed_weekdays": [1, 3, 5], "required_periods": [], "fixed_date": None,
                             "fixed_start_time": None},
        "soft_preferences": {"preferred_periods": []},
        "provenance": [], "critical_missing": [], "assumptions": [],
    }
    service = PlanningLLMService(FakeJSONClient(payload))

    result = await service.run_phase_a({"user_input": "每周一下午快走30分钟"})

    item = result.items[0]
    assert result.decision.value == "ready"
    assert item.facts.start_time.strftime("%H:%M") == "14:00"
    assert item.hard_constraints.required_periods == ["afternoon"]
    assert item.provenance[-1].display_label == "AI猜测，可修改"


@pytest.mark.asyncio
async def test_phase_a_applies_a_shared_weekend_clause_to_both_goals() -> None:
    payload = phase_a_payload()
    payload["items"] = [
        {
            "item_id": "badminton", "kind": "abstract_goal", "source_text": "最近一个月周末打羽毛球",
            "title": "周末打羽毛球",
            "facts": {"date": None, "start_time": None, "end_time": None, "duration_minutes": None,
                      "deadline": "2026-10-23", "stated_frequency": "每周末", "activity": "打羽毛球",
                      "result_metric": None},
            "hard_constraints": {"allowed_weekdays": [6, 7], "required_periods": []},
            "soft_preferences": {"preferred_periods": []}, "provenance": [], "critical_missing": [], "assumptions": [],
        },
        {
            "item_id": "interview", "kind": "abstract_goal", "source_text": "准备面试", "title": "准备面试",
            "facts": {"date": None, "start_time": None, "end_time": None, "duration_minutes": None,
                      "deadline": "2026-10-23", "stated_frequency": None, "activity": "准备面试",
                      "result_metric": None},
            "hard_constraints": {"allowed_weekdays": [], "required_periods": []},
            "soft_preferences": {"preferred_periods": []}, "provenance": [], "critical_missing": [], "assumptions": [],
        },
    ]
    service = PlanningLLMService(FakeJSONClient(payload))

    result = await service.run_phase_a({
        "user_input": "最近一个月我想周末都打打羽毛球和准备准备面试",
        "reference_now": "2026-09-23T10:00:00+08:00",
    })

    assert [item.hard_constraints.allowed_weekdays for item in result.items] == [[6, 7], [6, 7]]
    assert any("同时约束" in note for note in result.global_assumptions)


@pytest.mark.asyncio
async def test_phase_a_does_not_share_weekend_when_the_input_says_weekdays_for_the_second_goal() -> None:
    payload = phase_a_payload()
    payload["items"][0]["kind"] = "abstract_goal"
    payload["items"][0]["hard_constraints"]["allowed_weekdays"] = [6, 7]
    payload["items"].append({**payload["items"][0], "item_id": "item_2", "title": "准备面试",
                             "source_text": "工作日准备面试",
                             "hard_constraints": {"allowed_weekdays": [], "required_periods": []}})
    service = PlanningLLMService(FakeJSONClient(payload))

    result = await service.run_phase_a({"user_input": "周末打羽毛球，工作日准备面试"})

    assert result.items[1].hard_constraints.allowed_weekdays == []


@pytest.mark.asyncio
async def test_phase_a_normalizes_chinese_period_names_in_constraints() -> None:
    payload = phase_a_payload()
    payload["items"][0]["hard_constraints"]["required_periods"] = ["下午"]
    payload["items"][0]["soft_preferences"]["preferred_periods"] = ["晚上"]
    service = PlanningLLMService(FakeJSONClient(payload))

    result = await service.run_phase_a({"user_input": "周三下午开会"})

    assert result.items[0].hard_constraints.required_periods == ["afternoon"]
    assert result.items[0].soft_preferences.preferred_periods == ["evening"]


def phase_a_for_goal_fixture(*, include_fixed: bool = False) -> PhaseAResult:
    payload = phase_a_payload()
    goal = {
        "item_id": "goal_1" if include_fixed else "item_1",
        "kind": "abstract_goal", "source_text": "会前准备", "title": "会前准备",
        "facts": {"date": None, "start_time": None, "end_time": None, "duration_minutes": None,
                  "deadline": None, "stated_frequency": None, "activity": "复习材料", "result_metric": None},
        "hard_constraints": {"allowed_weekdays": [], "required_periods": []},
        "soft_preferences": {"preferred_periods": []},
        "provenance": [], "critical_missing": [], "assumptions": [],
    }
    payload["items"] = [payload["items"][0], goal] if include_fixed else [goal]
    return PhaseAResult.model_validate(payload)


@pytest.mark.asyncio
async def test_phase_b_strips_display_labels_the_model_copies_onto_containers() -> None:
    fixture = phase_b_payload()
    fixture["fixed_events"][0]["display_label"] = "明确安排"
    fixture["goal_plans"] = [{
        "source_item_id": "goal_1",
        "goal_title": "会前准备",
        "deadline": None,
        "deadline_provenance": None,
        "importance": "medium",
        "urgency": "medium",
        "suggested_goal_horizon_days": 2,
        "display_label": "AI建议，可修改或删除",
        "assumptions": [],
        "task_templates": [{
            "task_id": "prep",
            "title": "会前准备",
            "activity_type": "study",
            "instructions": "复习材料",
            "duration_minutes": 30,
            "occurrences_within_window": 2,
            "frequency_per_week": 3,
            "min_gap_hours": 0,
            "depends_on": [],
            "hard_constraints": {"allowed_weekdays": [], "required_periods": [], "fixed_date": None,
                                 "fixed_start_time": None},
            "soft_preferences": {"preferred_periods": []},
            "source": "ai_suggestion",
            "display_label": "AI建议，可修改或删除",
            "provenance": [],
            "assumptions": [],
        }],
    }]
    service = PlanningLLMService(FakeJSONClient(fixture))

    result = await service.run_phase_b(phase_a_for_goal_fixture(include_fixed=True), {"timezone": "Asia/Shanghai"})

    # 能通过校验本身即证明多余的 display_label 已被剥离（否则 extra_forbidden）
    assert len(result.goal_plans) == 1
    assert result.goal_plans[0].task_templates[0].task_id == "prep"


def _plan_fixture(task_overrides: dict) -> dict:
    return {
        "source_item_id": "item_1",
        "goal_title": "会前准备",
        "deadline": None,
        "deadline_provenance": None,
        "importance": "medium",
        "urgency": "medium",
        "suggested_goal_horizon_days": 2,
        "assumptions": [],
        "task_templates": [{
            "task_id": "prep",
            "title": "会前准备",
            "activity_type": "study",
            "instructions": "复习材料",
            "duration_minutes": 30,
            "occurrences_within_window": 2,
            "frequency_per_week": 3,
            "min_gap_hours": 0,
            "depends_on": [],
            "hard_constraints": {"allowed_weekdays": [], "required_periods": [], "fixed_date": None,
                                 "fixed_start_time": None},
            "soft_preferences": {"preferred_periods": []},
            "source": "ai_suggestion",
            "provenance": [],
            "assumptions": [],
        } | task_overrides],
    }


@pytest.mark.asyncio
async def test_phase_b_repairs_malformed_provenance() -> None:
    fixture = phase_b_payload()
    fixture["fixed_events"] = []
    fixture["goal_plans"] = [_plan_fixture({
        "min_gap_hours": 48,
        # 模型把 provenance 写成对象（而不是对象数组）——之前会直接 AttributeError 崩溃
        "provenance": {"task_template.min_gap_hours": "模型说明"},
    })]
    service = PlanningLLMService(FakeJSONClient(fixture))

    result = await service.run_phase_b(phase_a_for_goal_fixture(), {"timezone": "Asia/Shanghai"})

    task = result.goal_plans[0].task_templates[0]
    assert task.min_gap_hours == 0
    assert all(entry.field_path == "task_template.min_gap_hours" for entry in task.provenance)


@pytest.mark.asyncio
async def test_phase_b_drops_string_provenance_entries_and_keeps_valid_ones() -> None:
    fixture = phase_b_payload()
    fixture["fixed_events"] = []
    fixture["goal_plans"] = [_plan_fixture({
        "provenance": ["只是一段文字", {
            "field_path": "task_template.duration_minutes", "value": 30,
            "source": "ai_assumption", "reason": "用户未提供时长", "user_editable": True,
            "display_label": "AI猜测，可修改",
        }],
    })]
    service = PlanningLLMService(FakeJSONClient(fixture))

    result = await service.run_phase_b(phase_a_for_goal_fixture(), {"timezone": "Asia/Shanghai"})

    entries = result.goal_plans[0].task_templates[0].provenance
    assert [entry.field_path for entry in entries] == ["task_template.duration_minutes"]


@pytest.mark.asyncio
async def test_phase_b_clamps_task_duration_over_90_minutes() -> None:
    fixture = phase_b_payload()
    fixture["fixed_events"] = []
    fixture["goal_plans"] = [_plan_fixture({"duration_minutes": 120})]
    service = PlanningLLMService(FakeJSONClient(fixture))

    result = await service.run_phase_b(phase_a_for_goal_fixture(), {"timezone": "Asia/Shanghai"})

    task = result.goal_plans[0].task_templates[0]
    assert task.duration_minutes == 90
    clamp_note = next(entry for entry in task.provenance if entry.field_path == "task_template.duration_minutes"
                      and entry.source.value == "system_derived")
    assert "已调整为 90 分钟" in clamp_note.reason


@pytest.mark.asyncio
async def test_phase_a_places_leave_one_day_before_the_main_activities() -> None:
    payload = phase_a_payload()
    payload["items"].append({
        "item_id": "item_2",
        "kind": "explicit_event",
        "source_text": "周三前请假一天前往A地处理流程",
        "title": "请假一天",
        "facts": {"date": None, "start_time": None, "end_time": None, "duration_minutes": None,
                  "deadline": None, "stated_frequency": None, "activity": "请假", "result_metric": None},
        "hard_constraints": {"allowed_weekdays": [], "required_periods": []},
        "soft_preferences": {"preferred_periods": []},
        "provenance": [], "critical_missing": [], "assumptions": [],
    })
    service = PlanningLLMService(FakeJSONClient(payload))

    result = await service.run_phase_a({"reference_now": "2026-08-31T09:00:00+08:00"})

    leave = next(item for item in result.items if item.item_id == "item_2")
    assert leave.facts.date.isoformat() == "2026-09-01"  # 主活动 9/2 的前一天
    assert leave.facts.start_time.strftime("%H:%M") == "09:00"
    assert leave.facts.duration_minutes == 480
    assert any("主活动前一天" in note for note in leave.assumptions)
    assert all(entry.display_label == "AI猜测，可修改" for entry in leave.provenance)


@pytest.mark.asyncio
async def test_phase_a_snaps_a_bare_weekday_to_the_nearest_occurrence() -> None:
    payload = phase_a_payload()
    payload["items"][0]["facts"]["date"] = "2026-09-23"  # 同样是周三，但比最近的周三晚了一周
    service = PlanningLLMService(FakeJSONClient(payload))

    # 2026-09-15 是周二，最近的周三是 9/16
    result = await service.run_phase_a({
        "reference_now": "2026-09-15T09:00:00+08:00",
        "user_input": "周三前我想请假前往A地处理流程",
    })

    assert result.items[0].facts.date.isoformat() == "2026-09-16"
    assert any(entry.field_path == "facts.date" and entry.source.value == "ai_assumption"
               for entry in result.items[0].provenance)


@pytest.mark.asyncio
async def test_phase_a_moves_leave_back_when_it_lands_after_the_main_activity() -> None:
    payload = phase_a_payload()
    payload["items"].append({
        "item_id": "item_2",
        "kind": "explicit_event",
        "source_text": "周三前请假一天",
        "title": "请假一天",
        "facts": {"date": "2026-09-22", "start_time": "09:00", "end_time": None, "duration_minutes": 480,
                  "deadline": None, "stated_frequency": None, "activity": "请假", "result_metric": None},
        "hard_constraints": {"allowed_weekdays": [], "required_periods": []},
        "soft_preferences": {"preferred_periods": []},
        "provenance": [], "critical_missing": [], "assumptions": [],
    })
    service = PlanningLLMService(FakeJSONClient(payload))

    result = await service.run_phase_a({
        "reference_now": "2026-09-15T09:00:00+08:00",
        "user_input": "周三前我想请假前往A地处理流程",
    })

    # 主活动 9/2 → 被校准到最近的周三 9/16；请假应回到 9/15（不晚于主活动、不早于今天）
    leave = next(item for item in result.items if item.item_id == "item_2")
    assert leave.facts.date.isoformat() == "2026-09-15"


@pytest.mark.asyncio
async def test_phase_a_keeps_a_correct_pre_action_date_and_related_fields_consistent() -> None:
    payload = phase_a_payload()
    payload["items"][0]["facts"].update({"date": "2026-09-23", "start_time": "10:00"})
    payload["items"][0]["hard_constraints"].update({"fixed_date": "2026-09-23", "fixed_start_time": "10:00"})
    payload["items"].append({
        "item_id": "leave",
        "kind": "explicit_event",
        "source_text": "周三前请假一天",
        "title": "请假",
        "facts": {"date": "2026-09-22", "start_time": "09:00", "end_time": None, "duration_minutes": 480,
                  "deadline": None, "stated_frequency": None, "activity": "请假", "result_metric": None},
        "hard_constraints": {"allowed_weekdays": [2], "required_periods": [],
                             "fixed_date": "2026-09-22", "fixed_start_time": "09:00"},
        "soft_preferences": {"preferred_periods": []},
        "provenance": [], "critical_missing": [], "assumptions": ["请假安排在主活动前一天"],
    })
    service = PlanningLLMService(FakeJSONClient(payload))

    result = await service.run_phase_a({
        "reference_now": "2026-09-18T10:00:00+08:00",
        "user_input": "周三前我想请假并参加会议",
    })

    leave = next(item for item in result.items if item.item_id == "leave")
    assert leave.facts.date.isoformat() == "2026-09-22"
    assert leave.facts.start_time.strftime("%H:%M") == "09:00"
    assert leave.facts.duration_minutes == 480
    assert leave.hard_constraints.fixed_date.isoformat() == "2026-09-22"
    assert leave.hard_constraints.allowed_weekdays == [2]


@pytest.mark.asyncio
async def test_phase_a_does_not_move_a_standalone_leave_event() -> None:
    payload = phase_a_payload()
    leave = payload["items"][0]
    leave.update({"item_id": "leave", "source_text": "周三请假一天", "title": "请假一天"})
    leave["facts"].update({"date": "2026-09-23", "start_time": "09:00", "duration_minutes": 480,
                           "activity": "请假"})
    leave["hard_constraints"].update({"allowed_weekdays": [3], "fixed_date": "2026-09-23",
                                      "fixed_start_time": "09:00"})
    service = PlanningLLMService(FakeJSONClient(payload))

    result = await service.run_phase_a({
        "reference_now": "2026-09-18T10:00:00+08:00",
        "user_input": "周三请假一天",
    })

    assert result.items[0].facts.date.isoformat() == "2026-09-23"


@pytest.mark.asyncio
async def test_phase_a_late_night_fallback_never_creates_a_past_start_time() -> None:
    payload = phase_a_payload()
    payload["items"][0]["facts"].update({"date": "2026-09-16", "start_time": "10:00"})
    payload["items"][0]["hard_constraints"].update({"fixed_date": "2026-09-16", "fixed_start_time": "10:00"})
    payload["items"].append({
        "item_id": "leave", "kind": "explicit_event", "source_text": "周三前请假", "title": "请假",
        "facts": {"date": None, "start_time": None, "end_time": None, "duration_minutes": None,
                  "deadline": None, "stated_frequency": None, "activity": "请假", "result_metric": None},
        "hard_constraints": {"allowed_weekdays": [], "required_periods": []},
        "soft_preferences": {"preferred_periods": []}, "provenance": [], "critical_missing": [], "assumptions": [],
    })
    service = PlanningLLMService(FakeJSONClient(payload))

    result = await service.run_phase_a({"reference_now": "2026-09-15T22:30:00+08:00"})

    leave = next(item for item in result.items if item.item_id == "leave")
    assert leave.facts.date.isoformat() == "2026-09-15"
    assert leave.facts.start_time.strftime("%H:%M") == "23:00"


@pytest.mark.asyncio
async def test_phase_a_keeps_dates_when_the_input_names_next_week() -> None:
    payload = phase_a_payload()
    payload["items"][0]["facts"]["date"] = "2026-09-23"
    service = PlanningLLMService(FakeJSONClient(payload))

    result = await service.run_phase_a({
        "reference_now": "2026-09-15T09:00:00+08:00",
        "user_input": "下周三我想去A地处理流程",
    })

    assert result.items[0].facts.date.isoformat() == "2026-09-23"


@pytest.mark.asyncio
async def test_phase_a_never_places_leave_in_the_past() -> None:
    payload = phase_a_payload()
    payload["items"].append({
        "item_id": "item_2",
        "kind": "explicit_event",
        "source_text": "周三前请假一天",
        "title": "请假一天",
        "facts": {"date": None, "start_time": None, "end_time": None, "duration_minutes": None,
                  "deadline": None, "stated_frequency": None, "activity": "请假", "result_metric": None},
        "hard_constraints": {"allowed_weekdays": [], "required_periods": []},
        "soft_preferences": {"preferred_periods": []},
        "provenance": [], "critical_missing": [], "assumptions": [],
    })
    service = PlanningLLMService(FakeJSONClient(payload))

    result = await service.run_phase_a({"reference_now": "2026-09-05T09:00:00+08:00"})

    leave = next(item for item in result.items if item.item_id == "item_2")
    assert leave.facts.date.isoformat() == "2026-09-05"  # 不早于今天


@pytest.mark.asyncio
async def test_phase_a_unexpected_normalization_crash_keeps_raw_output_for_diagnostics(monkeypatch) -> None:
    from app.llm import service as service_module

    def boom(_value):
        raise RuntimeError("归一化崩溃")

    monkeypatch.setattr(service_module, "normalize_assumption_lists", boom)
    service = PlanningLLMService(FakeJSONClient(phase_a_payload()))

    with pytest.raises(ModelOutputValidationError) as captured:
        await service.run_phase_a({"user_input": "周三下午开会"})

    assert captured.value.raw_output  # raw 输出必须保留进诊断
    assert captured.value.validation_errors[0]["type"] == "internal.normalization_error"


@pytest.mark.asyncio
async def test_phase_a_tolerates_invented_constraint_field_names() -> None:
    payload = phase_a_payload()
    payload["items"].append({
        "item_id": "item_2",
        "kind": "explicit_event",
        "source_text": "周三宣讲会",
        "title": "宣讲会",
        "facts": {"date": "2026-09-09", "start_time": "19:00", "end_time": None, "duration_minutes": 60,
                  "deadline": None, "stated_frequency": None, "activity": "宣讲会", "result_metric": None},
        "hard_constraints": {"allowed_weekdays": [3], "required_periods": ["evening"], "fixed_date": "2026-09-09",
                             "fixed_start_time": "19:00",
                             "required_occurrences_within_week": 1},
        "soft_preferences": {"preferred_periods": [], "pacing": "neutral"},
        "provenance": [], "critical_missing": [], "assumptions": [],
    })
    service = PlanningLLMService(FakeJSONClient(payload))

    result = await service.run_phase_a({"user_input": "周三宣讲会包含未知约束字段"})

    event = next(item for item in result.items if item.item_id == "item_2")
    assert "required_occurrences_within_week" not in event.hard_constraints.model_dump()
    assert any("已忽略" in note for note in event.assumptions)


@pytest.mark.asyncio
@pytest.mark.parametrize("bad_value,expected", [
    (6, [6]),
    ("周六", [6]),
    ("6,7", [6, 7]),
    ({"周六": True}, []),
])
async def test_phase_a_repairs_malformed_allowed_weekdays(bad_value, expected) -> None:
    payload = phase_a_payload()
    payload["items"][0]["hard_constraints"]["allowed_weekdays"] = bad_value
    service = PlanningLLMService(FakeJSONClient(payload))

    result = await service.run_phase_a({"user_input": "周三下午开会"})

    assert result.items[0].hard_constraints.allowed_weekdays == expected
    if not isinstance(bad_value, list):
        assert any("星期约束" in note for note in result.items[0].assumptions)
