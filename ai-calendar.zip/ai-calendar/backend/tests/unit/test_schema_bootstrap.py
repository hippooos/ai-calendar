from sqlalchemy import inspect

from app.config import Settings
from app.main import create_app
from app.persistence.db import create_database_engine


def test_create_app_does_not_bypass_alembic_migrations(tmp_path) -> None:
    database_url = f"sqlite+pysqlite:///{tmp_path / 'unmigrated.db'}"

    create_app(settings=Settings(database_url=database_url))

    assert inspect(create_database_engine(database_url)).get_table_names() == []
