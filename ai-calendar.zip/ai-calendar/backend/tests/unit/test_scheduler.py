from datetime import datetime, time, timedelta
from zoneinfo import ZoneInfo

from app.planning.scheduler import BusyInterval, ScheduleRequest, ScheduleTask, SleepWindow, schedule

TZ = ZoneInfo("Asia/Shanghai")


def window(days: int = 14):
    start = datetime(2026, 8, 31, 9, 0, tzinfo=TZ)
    return start, start + timedelta(days=days)


def test_scheduler_respects_hard_weekdays_and_36_hour_gap() -> None:
    start, end = window()
    task = ScheduleTask("walk", "散步", 30, 3, allowed_weekdays=(1, 3, 5), required_periods=("evening",), min_gap_hours=36)

    result = schedule(ScheduleRequest(start, end, (task,)))

    assert [item.start.isoweekday() for item in result.scheduled_items] == [1, 3, 5]
    assert all(item.start.hour == 18 for item in result.scheduled_items)
    assert all((right.start - left.start) >= timedelta(hours=36) for left, right in zip(result.scheduled_items, result.scheduled_items[1:]))


def test_scheduler_avoids_busy_interval_but_allows_touching_boundary() -> None:
    start, end = window(2)
    task = ScheduleTask("read", "阅读", 60, 1, required_periods=("morning",))
    busy = (BusyInterval(start=start, end=start + timedelta(hours=1)),)

    result = schedule(ScheduleRequest(start, end, (task,), busy=busy))

    assert result.scheduled_items[0].start == start + timedelta(hours=1)


def test_scheduler_uses_non_preferred_period_when_preference_is_unavailable() -> None:
    start, end = window(1)
    task = ScheduleTask("read", "阅读", 30, 1, preferred_periods=("evening",))
    busy = (BusyInterval(start.replace(hour=18), start.replace(hour=22)),)

    result = schedule(ScheduleRequest(start, end, (task,), busy=busy))

    assert result.scheduled_items[0].start.hour < 18


def test_scheduler_does_not_relax_hard_weekday_when_no_slot_exists() -> None:
    start, end = window(2)
    task = ScheduleTask("walk", "散步", 30, 1, allowed_weekdays=(1,), required_periods=("evening",))
    busy = (BusyInterval(start.replace(hour=18), start.replace(hour=22)),)

    result = schedule(ScheduleRequest(start, end, (task,), busy=busy))

    assert result.scheduled_items == ()
    assert result.unscheduled_items[0].missing_occurrences == 1
    assert "硬约束" in result.unscheduled_items[0].reason


def test_scheduler_never_places_items_in_sleep_or_outside_window() -> None:
    start, end = window(1)
    task = ScheduleTask("write", "写作", 90, 8)

    result = schedule(ScheduleRequest(start, end, (task,), sleep=SleepWindow(time(22), time(8))))

    assert all(start <= item.start and item.end <= end for item in result.scheduled_items)
    assert all(8 <= item.start.hour < 22 and item.end.hour <= 22 for item in result.scheduled_items)


def test_scheduler_is_deterministic() -> None:
    start, end = window()
    request = ScheduleRequest(start, end, (ScheduleTask("read", "阅读", 30, 4, min_gap_hours=24),))

    assert schedule(request) == schedule(request)


def test_dependent_task_is_not_scheduled_when_dependency_has_no_slot() -> None:
    start, end = window(1)
    blocked = ScheduleTask("blocked", "前置任务", 60, 1, allowed_weekdays=(7,))
    dependent = ScheduleTask("dependent", "后续任务", 30, 1, depends_on=("blocked",))

    result = schedule(ScheduleRequest(start, end, (blocked, dependent)))

    assert result.scheduled_items == ()
    assert result.unscheduled_items[1].reason == "依赖任务未排入"


def test_scheduler_never_places_a_task_after_its_finish_deadline() -> None:
    start, end = window(14)
    deadline = datetime(2026, 9, 3, 14, 0, tzinfo=TZ)
    task = ScheduleTask("prepare", "面试准备", 60, 2, min_gap_hours=12, must_finish_before=deadline)

    result = schedule(ScheduleRequest(start, end, (task,)))

    assert len(result.scheduled_items) == 2
    assert all(item.end <= deadline for item in result.scheduled_items)


def test_daily_task_is_scheduled_at_most_once_per_calendar_day() -> None:
    start = datetime(2026, 9, 1, 9, 0, tzinfo=TZ)
    end = datetime(2026, 9, 3, 14, 0, tzinfo=TZ)
    task = ScheduleTask("prepare", "面试准备", 60, 2, min_gap_hours=12, frequency_per_week=7)

    result = schedule(ScheduleRequest(start, end, (task,)))

    assert len(result.scheduled_items) == 2
    assert len({item.start.date() for item in result.scheduled_items}) == 2


def test_explicit_weekly_frequency_spreads_weekend_tasks_across_weeks() -> None:
    start = datetime(2026, 9, 23, 10, 0, tzinfo=TZ)
    end = datetime(2026, 10, 23, 10, 0, tzinfo=TZ)
    task = ScheduleTask(
        "badminton", "打羽毛球", 60, 4,
        allowed_weekdays=(6, 7), frequency_per_week=1, enforce_frequency_per_week=True,
    )

    result = schedule(ScheduleRequest(start, end, (task,)))

    assert [item.start.date().isoformat() for item in result.scheduled_items] == [
        "2026-09-26", "2026-10-03", "2026-10-10", "2026-10-17",
    ]


def test_explicit_twice_weekly_weekend_task_uses_both_weekend_days() -> None:
    start = datetime(2026, 9, 18, 10, 0, tzinfo=TZ)
    end = datetime(2026, 9, 28, 10, 0, tzinfo=TZ)
    task = ScheduleTask(
        "prep", "准备面试", 60, 4,
        allowed_weekdays=(6, 7), frequency_per_week=2, enforce_frequency_per_week=True,
    )

    result = schedule(ScheduleRequest(start, end, (task,)))

    assert [item.start.date().isoformat() for item in result.scheduled_items] == [
        "2026-09-19", "2026-09-20", "2026-09-26", "2026-09-27",
    ]


def test_distributed_study_preference_spreads_tasks_across_days_without_a_hard_gap() -> None:
    start = datetime(2026, 9, 1, 9, 0, tzinfo=TZ)
    end = datetime(2026, 9, 4, 18, 0, tzinfo=TZ)
    task = ScheduleTask("prep", "面试准备", 30, 3, pacing="distributed")

    result = schedule(ScheduleRequest(start, end, (task,)))

    assert [item.start.date().isoformat() for item in result.scheduled_items] == ["2026-09-01", "2026-09-02", "2026-09-03"]


def test_fragmented_pacing_spreads_tasks_instead_of_filling_one_day() -> None:
    """“碎片时间”曾因缺少分支被当成 neutral，导致多次安排全挤在同一天晚上。"""
    start = datetime(2026, 9, 1, 9, 0, tzinfo=TZ)
    end = datetime(2026, 9, 5, 22, 0, tzinfo=TZ)
    task = ScheduleTask("prep", "面试准备", 30, 4, pacing="fragmented")

    result = schedule(ScheduleRequest(start, end, (task,)))

    dates = [item.start.date() for item in result.scheduled_items]
    assert len(dates) == 4
    assert len(set(dates)) == 4, f"碎片时间应分散到不同日期，实际：{dates}"


def test_compact_pacing_still_prefers_the_same_day() -> None:
    start = datetime(2026, 9, 1, 9, 0, tzinfo=TZ)
    end = datetime(2026, 9, 4, 18, 0, tzinfo=TZ)
    task = ScheduleTask("prep", "面试准备", 30, 3, pacing="compact")

    result = schedule(ScheduleRequest(start, end, (task,)))

    assert len({item.start.date() for item in result.scheduled_items}) == 1
