import pytest
from pydantic import ValidationError

from app.config import Settings


def test_local_mode_does_not_require_access_code() -> None:
    settings = Settings(_env_file=None, app_mode="local", app_access_code=None)

    assert settings.app_mode == "local"
    assert settings.app_access_code is None
    assert settings.bind_host == "127.0.0.1"
    assert settings.llm_timeout_seconds == 120


def test_deployed_mode_rejects_missing_access_code() -> None:
    with pytest.raises(ValidationError, match="APP_ACCESS_CODE"):
        Settings(app_mode="deployed", app_access_code=None)


def test_deployed_mode_accepts_non_empty_access_code() -> None:
    settings = Settings(app_mode="deployed", app_access_code="owner-secret")

    assert settings.bind_host == "0.0.0.0"
    assert settings.app_access_code == "owner-secret"
