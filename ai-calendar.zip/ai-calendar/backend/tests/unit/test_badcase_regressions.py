"""坏例回归测试。

fixtures/badcases/ 下的每一份 JSON 都是真实网关曾经产出、并导致草案失败的模型原始输出
（取自本机 model_runs.diagnostic_json）。它们固化"网关不守 schema"的真实坏法：
每次新增兜底后都应有对应 fixture，避免以后再犯。

新增坏例：运行 tools/prompt-tests/capture_badcases.py 从本机数据库导出。
"""
import json
from pathlib import Path

import pytest

from app.llm.service import PlanningLLMService
from app.prompts.schemas import PhaseAResult

FIXTURES = Path(__file__).resolve().parents[1] / "fixtures" / "badcases"


def load(name: str) -> dict:
    return json.loads((FIXTURES / name).read_text(encoding="utf-8"))


class StaticClient:
    """按 fixture 提供原始模型输出，不发起任何真实调用。"""

    def __init__(self, raw: dict) -> None:
        self._raw = raw

    async def complete_json(self, *, system_prompt: str, payload: dict) -> dict:
        return json.loads(json.dumps(self._raw, ensure_ascii=False))


def phase_a_matching(phase_b_raw: dict) -> PhaseAResult:
    """由阶段 B 坏例反推出一个能通过跨阶段校验的阶段 A 结果。"""
    items = []
    for event in phase_b_raw.get("fixed_events", []):
        items.append({
            "item_id": event["source_item_id"],
            "kind": "explicit_event",
            "source_text": event["title"],
            "title": event["title"],
            "facts": {
                "date": event["date"], "start_time": event["start_time"], "end_time": event["end_time"],
                "duration_minutes": event["duration_minutes"], "deadline": None, "stated_frequency": None,
                "activity": event["title"], "result_metric": None,
            },
            "hard_constraints": {
                "allowed_weekdays": [], "required_periods": [],
                "fixed_date": event["date"], "fixed_start_time": event["start_time"],
            },
            "soft_preferences": {"preferred_periods": []},
            "provenance": [], "critical_missing": [], "assumptions": [],
        })
    for plan in phase_b_raw.get("goal_plans", []):
        items.append({
            "item_id": plan["source_item_id"],
            "kind": "abstract_goal",
            "source_text": plan.get("goal_title", "目标"),
            "title": plan.get("goal_title", "目标"),
            "facts": {
                "date": None, "start_time": None, "end_time": None, "duration_minutes": None,
                "deadline": plan.get("deadline"), "stated_frequency": None,
                "activity": None, "result_metric": None,
            },
            "hard_constraints": {"allowed_weekdays": [], "required_periods": []},
            "soft_preferences": {"preferred_periods": []},
            "provenance": [], "critical_missing": [], "assumptions": [],
        })
    return PhaseAResult.model_validate({
        "decision": "ready", "items": items, "questions": [], "manual_required": None, "global_assumptions": [],
    })


@pytest.mark.asyncio
async def test_phase_a_drops_the_invented_constraint_field() -> None:
    raw = load("phase_a_extra_forbidden_required_occurrences_within_week.json")
    # fixture 本身仍然复现坏法：模型发明了 required_occurrences_within_week
    invented = [
        item for item in raw.get("items", [])
        if "required_occurrences_within_week" in (item.get("hard_constraints") or {})
    ]
    assert invented, "fixture 必须保留'发明字段'这一坏法，否则断言失去意义"

    result = await PlanningLLMService(StaticClient(raw)).run_phase_a({"user_input": "复合行程输入"})

    for item in result.items:
        assert "required_occurrences_within_week" not in item.hard_constraints.model_dump()
    assert any("已忽略" in note for item in result.items for note in item.assumptions)


@pytest.mark.asyncio
async def test_phase_a_repairs_null_allowed_weekdays() -> None:
    raw = load("phase_a_list_type_allowed_weekdays.json")
    broken = [
        item for item in raw.get("items", [])
        if not isinstance((item.get("hard_constraints") or {}).get("allowed_weekdays"), list)
    ]
    assert broken, "fixture 必须保留'星期约束非列表'这一坏法"

    result = await PlanningLLMService(StaticClient(raw)).run_phase_a({"user_input": "最近一个月周末安排"})

    assert all(isinstance(item.hard_constraints.allowed_weekdays, list) for item in result.items)
    assert any("星期约束" in note for item in result.items for note in item.assumptions)


@pytest.mark.asyncio
async def test_phase_b_tolerates_display_label_copied_onto_the_task() -> None:
    raw = load("phase_b_extra_forbidden_display_label.json")
    assert "display_label" in raw["goal_plans"][0]["task_templates"][0], "fixture 必须保留多余 display_label"

    result = await PlanningLLMService(StaticClient(raw)).run_phase_b(phase_a_matching(raw), {"timezone": "Asia/Shanghai"})

    task = result.goal_plans[0].task_templates[0]
    assert not hasattr(task, "display_label")
    assert task.provenance or task.assumptions  # 原始标签信息仍在 provenance/assumptions 中可见


@pytest.mark.asyncio
async def test_phase_b_repairs_the_misspelled_provenance_source_enum() -> None:
    raw = load("phase_b_enum_source.json")
    misspelled = [
        entry for plan in raw.get("goal_plans", []) for task in plan.get("task_templates", [])
        for entry in task.get("provenance", []) if entry.get("source") == "ai_assuggestion"
    ]
    assert misspelled, "fixture 必须保留'provenance source 拼写错误'这一坏法"

    result = await PlanningLLMService(StaticClient(raw)).run_phase_b(phase_a_matching(raw), {"timezone": "Asia/Shanghai"})

    for plan in result.goal_plans:
        for task in plan.task_templates:
            for entry in task.provenance:
                assert entry.source.value in ("user_input", "user_profile", "system_derived", "ai_assumption", "ai_suggestion")


@pytest.mark.asyncio
async def test_phase_a_maps_integer_question_targets_to_item_ids() -> None:
    raw = load("phase_a_string_type_0.json")
    integer_targets = [
        question for question in raw.get("questions", [])
        if any(isinstance(value, int) for value in question.get("covers_item_ids", []))
    ]
    assert integer_targets, "fixture 必须保留'covers_item_ids 用整数'这一坏法"

    result = await PlanningLLMService(StaticClient(raw)).run_phase_a({"user_input": "复合行程输入"})

    for question in result.questions:
        assert question.covers_item_ids, "整数目标应映射成对应 item_id，而不是被清空"
        assert all(isinstance(value, str) for value in question.covers_item_ids)


@pytest.mark.asyncio
async def test_phase_b_clamps_the_oversized_duration_from_the_badcase() -> None:
    raw = load("phase_b_less_than_equal_duration_minutes.json")
    oversized = [
        task for plan in raw["goal_plans"] for task in plan.get("task_templates", [])
        if (task.get("duration_minutes") or 0) > 90
    ]
    assert oversized, "fixture 必须保留'单任务时长超过 90 分钟'这一坏法"

    result = await PlanningLLMService(StaticClient(raw)).run_phase_b(phase_a_matching(raw), {"timezone": "Asia/Shanghai"})

    templates = [task for plan in result.goal_plans for task in plan.task_templates]
    assert templates
    assert all(task.duration_minutes <= 90 for task in templates)
    assert any(
        entry.source.value == "system_derived" and entry.field_path == "task_template.duration_minutes"
        for task in templates for entry in task.provenance
    )
