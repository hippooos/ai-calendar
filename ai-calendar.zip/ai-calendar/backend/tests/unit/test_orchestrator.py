from datetime import datetime, timezone

import pytest

from app.domain.enums import PlanningStatus
from app.persistence.db import Base, create_session_factory, create_sqlite_engine
from app.persistence.repositories import ModelRunRepository, PlanningSessionRepository
from app.planning.orchestrator import InvalidStateTransition, PlanningOrchestrator, parse_time_answer
from app.llm.service import ModelOutputValidationError
from app.prompts.schemas import PhaseAResult, PhaseBResult
from tests.contract.test_prompt_schemas import phase_a_payload, phase_b_payload


class FakeLLMService:
    def __init__(self, phase_a=None, phase_b=None, error=None):
        self.phase_a = phase_a
        self.phase_b = phase_b
        self.error = error

    async def run_phase_a(self, context):
        if self.error: raise self.error
        return self.phase_a

    async def run_phase_b(self, phase_a, context):
        if self.error: raise self.error
        return self.phase_b


@pytest.fixture
def repo():
    engine = create_sqlite_engine("sqlite+pysqlite:///:memory:")
    Base.metadata.create_all(engine)
    with create_session_factory(engine)() as db:
        yield PlanningSessionRepository(db)


@pytest.mark.asyncio
async def test_submit_ready_input_moves_session_to_a_ready(repo) -> None:
    service = FakeLLMService(phase_a=PhaseAResult.model_validate(phase_a_payload()))
    orchestrator = PlanningOrchestrator(repo, service)

    session = await orchestrator.submit(raw_input="开会", reference_now=datetime.now(timezone.utc), context={})

    assert session.status == PlanningStatus.A_READY.value
    assert session.phase_a_json["decision"] == "ready"
    runs = ModelRunRepository(repo.db).list_for_session(session.id)
    assert [(run.stage, run.status) for run in runs] == [("a", "succeeded")]


@pytest.mark.asyncio
async def test_submit_clarification_moves_session_to_needs_clarification(repo) -> None:
    payload = phase_a_payload()
    payload["decision"] = "needs_clarification"
    payload["questions"] = [{"question_id":"q1","priority":20,"missing_field":"facts.date","question":"哪一天？","covers_item_ids":["item_1"]}]
    service = FakeLLMService(phase_a=PhaseAResult.model_validate(payload))

    session = await PlanningOrchestrator(repo, service).submit(raw_input="安排开会", reference_now=datetime.now(timezone.utc), context={})

    assert session.status == PlanningStatus.NEEDS_CLARIFICATION.value


@pytest.mark.asyncio
async def test_submit_model_failure_is_persisted(repo) -> None:
    orchestrator = PlanningOrchestrator(repo, FakeLLMService(error=RuntimeError("gateway down")))

    with pytest.raises(RuntimeError, match="gateway down"):
        await orchestrator.submit(raw_input="开会", reference_now=datetime.now(timezone.utc), context={})

    assert repo.list_all()[0].status == PlanningStatus.MODEL_FAILED.value
    assert repo.list_all()[0].error_code == "MODEL_ERROR"
    assert ModelRunRepository(repo.db).list_for_session(repo.list_all()[0].id)[0].status == "failed"


@pytest.mark.asyncio
async def test_submit_invalid_model_output_persists_local_diagnostics(repo) -> None:
    error = ModelOutputValidationError(
        raw_output={"decision": "ready", "items": "not-an-array"},
        validation_errors=[{"loc": ("items",), "msg": "Input should be a valid list", "type": "list_type"}],
    )
    with pytest.raises(ModelOutputValidationError):
        await PlanningOrchestrator(repo, FakeLLMService(error=error)).submit(
            raw_input="无个人信息测试", reference_now=datetime.now(timezone.utc), context={}
        )

    session = repo.list_all()[0]
    run = ModelRunRepository(repo.db).list_for_session(session.id)[0]
    assert session.status == PlanningStatus.VALIDATION_FAILED.value
    assert run.diagnostic_json == {
        "raw_model_output": {"decision": "ready", "items": "not-an-array"},
        "validation_errors": [{"loc": ["items"], "msg": "Input should be a valid list", "type": "list_type"}],
    }


@pytest.mark.asyncio
async def test_build_templates_rejects_session_before_a_ready(repo) -> None:
    session = repo.create(raw_input="开会", reference_now=datetime.now(timezone.utc))
    orchestrator = PlanningOrchestrator(repo, FakeLLMService())

    with pytest.raises(InvalidStateTransition, match="a_ready"):
        await orchestrator.build_templates(session_id=session.id, context={})


@pytest.mark.asyncio
async def test_build_templates_persists_phase_b(repo) -> None:
    phase_a = PhaseAResult.model_validate(phase_a_payload())
    phase_b = PhaseBResult.model_validate(phase_b_payload())
    service = FakeLLMService(phase_a=phase_a, phase_b=phase_b)
    orchestrator = PlanningOrchestrator(repo, service)
    session = await orchestrator.submit(raw_input="开会", reference_now=datetime.now(timezone.utc), context={})

    updated = await orchestrator.build_templates(session_id=session.id, context={})

    assert updated.status == PlanningStatus.B_READY.value
    assert updated.phase_b_json["decision"] == "ready_for_scheduling"


@pytest.mark.asyncio
async def test_build_templates_passes_the_session_reference_time_to_phase_b(repo) -> None:
    phase_a = PhaseAResult.model_validate(phase_a_payload())
    phase_b = PhaseBResult.model_validate(phase_b_payload())
    service = FakeLLMService(phase_a=phase_a, phase_b=phase_b)
    orchestrator = PlanningOrchestrator(repo, service)
    reference = datetime(2026, 9, 1, 15, 53, tzinfo=timezone.utc)
    session = await orchestrator.submit(raw_input="开会", reference_now=reference, context={})
    captured = {}

    async def capture(phase_a_result, context):
        captured.update(context)
        return phase_b

    service.run_phase_b = capture
    await orchestrator.build_templates(session_id=session.id, context={"timezone": "Asia/Shanghai"})

    assert captured["reference_now"] == reference.isoformat()


@pytest.mark.asyncio
async def test_answer_clarification_reuses_session_and_persists_answer(repo) -> None:
    needs = phase_a_payload()
    needs["decision"] = "needs_clarification"
    needs["questions"] = [{"question_id":"q1","priority":20,"missing_field":"facts.date","question":"哪一天？","covers_item_ids":["item_1"]}]
    ready = PhaseAResult.model_validate(phase_a_payload())
    first_service = FakeLLMService(phase_a=PhaseAResult.model_validate(needs))
    session = await PlanningOrchestrator(repo, first_service).submit(raw_input="安排开会", reference_now=datetime.now(timezone.utc), context={})

    updated = await PlanningOrchestrator(repo, FakeLLMService(phase_a=ready)).answer(
        session_id=session.id, answers={"q1":"2026年9月2日"}, context={}
    )

    assert updated.id == session.id
    assert updated.status == PlanningStatus.A_READY.value
    assert repo.get_answers(session.id) == {"q1":"2026年9月2日"}


@pytest.mark.asyncio
async def test_answering_a_start_period_uses_a_deterministic_time_without_second_phase_a_call(repo) -> None:
    needs = phase_a_payload()
    needs["decision"] = "needs_clarification"
    needs["questions"] = [{
        "question_id": "q_start",
        "priority": 30,
        "missing_field": "facts.start_time",
        "question": "AI面试几点开始？",
        "covers_item_ids": ["item_1"],
    }]
    needs["items"].append({
        "item_id": "item_2",
        "kind": "abstract_goal",
        "source_text": "我想在面试之前准备",
        "title": "面试准备",
        "facts": {"date": None, "start_time": None, "end_time": None, "duration_minutes": None,
                  "deadline": "2026-09-02", "stated_frequency": None, "activity": "面试准备", "result_metric": None},
        "hard_constraints": {"allowed_weekdays": [], "required_periods": [], "fixed_date": None,
                             "fixed_start_time": None, "must_finish_before": "2026-09-02T00:00:00+08:00"},
        "soft_preferences": {"preferred_periods": []},
        "provenance": [], "critical_missing": [], "assumptions": [],
    })
    first_service = FakeLLMService(phase_a=PhaseAResult.model_validate(needs))
    session = await PlanningOrchestrator(repo, first_service).submit(
        raw_input="后天有个AI面试，我想在之前每天准备",
        reference_now=datetime.now(timezone.utc),
        context={},
    )
    class NoSecondPhaseAService(FakeLLMService):
        async def run_phase_a(self, context):
            raise AssertionError("选择上午、下午或晚上后不应再次调用阶段 A 模型")

    updated = await PlanningOrchestrator(repo, NoSecondPhaseAService()).answer(
        session_id=session.id,
        answers={"q_start": "afternoon"},
        context={},
    )

    item = updated.phase_a_json["items"][0]
    assert updated.status == PlanningStatus.A_READY.value
    assert item["facts"]["start_time"] == "14:00:00"
    assert item["hard_constraints"]["fixed_start_time"] == "14:00:00"
    assert item["hard_constraints"]["required_periods"] == ["afternoon"]
    assert item["provenance"][-1]["source"] == "ai_assumption"
    assert item["provenance"][-1]["display_label"] == "AI猜测，可修改"
    assert updated.phase_a_json["items"][1]["hard_constraints"]["must_finish_before"] == "2026-09-02T14:00:00+08:00"
    assert repo.get_answers(session.id) == {"q_start": "afternoon"}


def test_parse_time_answer_handles_common_formats() -> None:
    from datetime import time as time_type

    assert parse_time_answer("15:30") == time_type(15, 30)
    assert parse_time_answer("14：00") == time_type(14, 0)
    assert parse_time_answer("下午3点半") == time_type(15, 30)
    assert parse_time_answer("下午三点半") == time_type(15, 30)
    assert parse_time_answer("15点30分") == time_type(15, 30)
    assert parse_time_answer("晚上8点") == time_type(20, 0)
    assert parse_time_answer("中午十二点") == time_type(12, 0)
    assert parse_time_answer("3点半", required_periods=["afternoon"]) == time_type(15, 30)
    assert parse_time_answer("两点半", required_periods=["afternoon"]) == time_type(14, 30)
    assert parse_time_answer("7点", required_periods=["evening"]) == time_type(19, 0)
    assert parse_time_answer("9点") == time_type(9, 0)


def test_parse_time_answer_rejects_ambiguous_answers() -> None:
    assert parse_time_answer("明天下午两点") is None
    assert parse_time_answer("周3下午") is None
    assert parse_time_answer("看情况") is None
    assert parse_time_answer("3点半") is None
    assert parse_time_answer("25:00") is None
    assert parse_time_answer("") is None


def _needs_start_time_payload(required_periods: list[str] | None = None) -> dict:
    needs = phase_a_payload()
    needs["decision"] = "needs_clarification"
    needs["questions"] = [{
        "question_id": "q_start",
        "priority": 30,
        "missing_field": "facts.start_time",
        "question": "AI面试几点开始？",
        "covers_item_ids": ["item_1"],
    }]
    if required_periods is not None:
        needs["items"][0]["hard_constraints"]["required_periods"] = required_periods
    return needs


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "answer,expected",
    [
        ("14：00", "14:00:00"),
        ("下午3点半", "15:30:00"),
        ("15点30分", "15:30:00"),
        ("两点半", "14:30:00"),
    ],
)
async def test_custom_time_answers_are_parsed_without_second_model_call(repo, answer, expected) -> None:
    needs = _needs_start_time_payload(required_periods=["afternoon"])
    session = await PlanningOrchestrator(repo, FakeLLMService(phase_a=PhaseAResult.model_validate(needs))).submit(
        raw_input="9月2日下午有个AI面试",
        reference_now=datetime.now(timezone.utc),
        context={},
    )

    class NoSecondPhaseAService(FakeLLMService):
        async def run_phase_a(self, context):
            raise AssertionError("可直接解析的时间答案不应再次调用阶段 A 模型")

    updated = await PlanningOrchestrator(repo, NoSecondPhaseAService()).answer(
        session_id=session.id,
        answers={"q_start": answer},
        context={},
    )

    item = updated.phase_a_json["items"][0]
    assert updated.status == PlanningStatus.A_READY.value
    assert item["facts"]["start_time"] == expected
    assert item["provenance"][-1]["source"] == "user_input"
    assert repo.get_answers(session.id) == {"q_start": answer}
    assert [row.answer for row in repo.list_answered(session.id)] == [answer]


@pytest.mark.asyncio
async def test_ambiguous_time_answers_fall_back_to_the_model(repo) -> None:
    needs = _needs_start_time_payload()
    session = await PlanningOrchestrator(repo, FakeLLMService(phase_a=PhaseAResult.model_validate(needs))).submit(
        raw_input="9月2日有个AI面试",
        reference_now=datetime.now(timezone.utc),
        context={},
    )
    ready = phase_a_payload()

    class TrackingService(FakeLLMService):
        def __init__(self):
            super().__init__(phase_a=PhaseAResult.model_validate(ready))
            self.called = False

        async def run_phase_a(self, context):
            self.called = True
            return await super().run_phase_a(context)

    service = TrackingService()
    updated = await PlanningOrchestrator(repo, service).answer(
        session_id=session.id,
        answers={"q_start": "明天下午两点"},
        context={},
    )

    assert service.called
    assert updated.status == PlanningStatus.A_READY.value
    assert repo.get_answers(session.id) == {"q_start": "明天下午两点"}
