import json

import httpx
import pytest

from app.llm.client import LLMInvalidResponse, LLMRequestError, OpenAICompatibleClient


def completion(content: str) -> httpx.Response:
    return httpx.Response(
        200,
        json={"choices": [{"message": {"content": content}}]},
    )


@pytest.mark.asyncio
async def test_complete_json_returns_decoded_model_object() -> None:
    expected = {"decision": "ready", "items": []}
    transport = httpx.MockTransport(lambda _: completion(json.dumps(expected)))
    client = OpenAICompatibleClient(
        base_url="https://model.example/v1",
        api_key="secret",
        model="glm-test",
        transport=transport,
    )

    result = await client.complete_json(system_prompt="system", payload={"input": "开会"})

    assert result == expected


@pytest.mark.asyncio
async def test_complete_json_retries_one_transport_failure() -> None:
    calls = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        if calls == 1:
            raise httpx.ConnectError("temporary", request=request)
        return completion('{"decision":"ready"}')

    client = OpenAICompatibleClient(
        base_url="https://model.example/v1",
        api_key=None,
        model="glm-test",
        transport=httpx.MockTransport(handler),
    )

    result = await client.complete_json(system_prompt="system", payload={})

    assert result == {"decision": "ready"}
    assert calls == 2


@pytest.mark.asyncio
async def test_complete_json_rejects_non_json_content() -> None:
    client = OpenAICompatibleClient(
        base_url="https://model.example/v1",
        api_key=None,
        model="glm-test",
        transport=httpx.MockTransport(lambda _: completion("not-json")),
    )

    with pytest.raises(LLMInvalidResponse, match="JSON"):
        await client.complete_json(system_prompt="system", payload={})


@pytest.mark.asyncio
async def test_authentication_error_is_not_retried() -> None:
    calls = 0

    def handler(_: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return httpx.Response(401, json={"error": "unauthorized"})

    client = OpenAICompatibleClient(
        base_url="https://model.example/v1",
        api_key="wrong",
        model="glm-test",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(LLMRequestError, match="401"):
        await client.complete_json(system_prompt="system", payload={})
    assert calls == 1


@pytest.mark.asyncio
async def test_request_reserves_enough_tokens_for_complete_schema() -> None:
    seen = {}
    def handler(request: httpx.Request) -> httpx.Response:
        seen.update(json.loads(request.content))
        return completion('{"decision":"ready"}')
    client = OpenAICompatibleClient(base_url="https://model.example/v1",api_key=None,model="glm-test",transport=httpx.MockTransport(handler))

    await client.complete_json(system_prompt="system",payload={})

    assert seen["max_tokens"] >= 3000


@pytest.mark.asyncio
async def test_structured_output_disables_default_glm_thinking() -> None:
    seen = {}

    def handler(request: httpx.Request) -> httpx.Response:
        seen.update(json.loads(request.content))
        return completion('{"decision":"ready"}')

    client = OpenAICompatibleClient(
        base_url="https://model.example/v1",
        api_key=None,
        model="glm-5.2",
        transport=httpx.MockTransport(handler),
    )

    await client.complete_json(system_prompt="system", payload={})

    assert seen["thinking"] == {"type": "disabled"}
